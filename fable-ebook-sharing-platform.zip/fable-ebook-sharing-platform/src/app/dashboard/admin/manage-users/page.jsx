import { getUsersList } from '@/lib/api/user';
import React from 'react';

const page = async () => {

    const data = await getUsersList();
    const users = data.users;
    console.log("Users list:", users);
    return (
        <div>
            
        </div>
    );
};

export default page;